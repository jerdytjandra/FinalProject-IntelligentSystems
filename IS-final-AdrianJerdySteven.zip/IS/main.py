from Forecaster import Forecaster
import pandas as pd
from matplotlib.pylab import rcParams
loop = True
loop2 = True

def configure():
    rcParams['figure.figsize'] = 15, 6
    dateparse = lambda dates: pd.datetime.strptime(dates, '%Y-%m')
    data = pd.read_csv('DataSet.csv', parse_dates=['Month'], index_col='Month', date_parser=dateparse)
    return data

while loop == True:
    print("Welcome to the Forecaster!")
    print("Commands include: \n 1. Checking dataset \n 2. Begin the Forecasting \n 3. Final Result \n 4. Exit Program")
    commands = input("Please input your commands.")
    data = configure()
    if commands == "1":
        print(data.head())
        print('\n Data Types:')
        print(data.dtypes)
        print(data.index)
    elif commands == "2":
        program = Forecaster(data,12)
        while loop2 == True:
            print("Which section you want to check?")
            print("1. Stationarity \n2.Log Stationarity \n3.Difference \n4.Residual \n5.Decomposition \n6.ACF \n7.PACF \n8.Unconverted Arima Model \n9.Exit")
            request = input("Please input the steps you wanted to check")
            if request == "1":
                program.basictest()
            if request == "2":
                program.logtest()
            if request == "3":
                program.difference()
            if request == "4":
                program.TSR()
            elif request == "5":
                program.decomposition()
            elif request == "6":
                program.acfnpacf()
            elif request == "7":
                ar = int(input("Please input the p value. Refer to 2.7, ACF to find it"))
                ma = int(input("Please input the q value. Refer to 2.8, PACF to find it"))
                program.arimamodel(ar,ma)
            elif request == "8":
                loop2 = False
            else:
                print("Not a valid request!")
        loop2 = True

    elif commands == "3":
        program = Forecaster(data,12)
        ar = int(input("Please input the p value. Refer to 2.7, ACF to find it"))
        ma = int(input("Please input the q value. Refer to 2.8, PACF to find it"))
        program.originalmodel(ar,ma)
    elif commands == "4":
        loop = False
    else:
        print("Unknown command, returning to main menu")